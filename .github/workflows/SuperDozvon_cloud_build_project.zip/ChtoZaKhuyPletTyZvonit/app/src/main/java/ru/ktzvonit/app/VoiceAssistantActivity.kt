package ru.ktzvonit.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class VoiceAssistantActivity : Activity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var reply: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        layout.addView(TextView(this).apply {
            text = "Голосовой помощник Супердозвон"
            textSize = 23f
        })
        status = TextView(this).apply { text = "\nНажми кнопку и говори по-русски."; textSize = 16f }
        heard = TextView(this).apply { text = "\nТы сказал: —"; textSize = 16f }
        reply = TextView(this).apply { text = "\nОтвет: готов слушать."; textSize = 16f }
        layout.addView(status)
        layout.addView(heard)
        layout.addView(reply)
        layout.addView(Button(this).apply {
            text = "🎙 Слушать"
            setOnClickListener { beginListening() }
        })
        layout.addView(Button(this).apply {
            text = "Повторить ответ"
            setOnClickListener { speak(reply.text.toString().removePrefix("\nОтвет: ")) }
        })
        setContentView(layout)

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 44)
        }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) tts?.language = Locale("ru", "RU")
    }

    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Распознавание речи недоступно на этом устройстве."
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 44)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "Слушаю…" }
            override fun onBeginningOfSpeech() { status.text = "Говори…" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Обрабатываю речь…" }
            override fun onError(error: Int) {
                status.text = "Не удалось распознать речь (код $error). Попробуй ещё раз."
            }
            override fun onResults(results: Bundle?) {
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                heard.text = "Ты сказал: $phrase"
                val answer = localReply(phrase)
                reply.text = "Ответ: $answer"
                status.text = "Готово."
                speak(answer)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(intent)
    }

    private fun localReply(text: String): String {
        val q = text.lowercase(Locale("ru", "RU"))
        return when {
            "привет" in q || "здравствуй" in q -> "Привет! Я Супердозвон. Чем помочь?"
            "как дела" in q -> "Работаю штатно. Готов помочь."
            "который час" in q || "сколько времени" in q ->
                "Посмотри время в строке состояния телефона. Доступ к точному времени я пока не подключил."
            "кто звонит" in q -> "Для определения звонков сначала включи соответствующую системную роль на главном экране."
            "пока" in q -> "До связи!"
            else -> "Я распознал твою фразу, но пока умею отвечать только на простые встроенные команды. Для свободного диалога нужно подключить ИИ-сервис."
        }
    }

    private fun speak(message: String) {
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "superdial_reply")
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
